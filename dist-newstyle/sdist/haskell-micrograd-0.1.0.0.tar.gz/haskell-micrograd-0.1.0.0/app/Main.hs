module Main where

import Neuron
import GradTree

main :: IO ()
main = putStrLn "Hello, Haskell!"
